package bishe.networkmonitor.dao;


import androidx.room.Database;
import androidx.room.RoomDatabase;

/**
 * Created by Dell on 5/1/2023.
 */

@Database(entities = {TextMsg.class}, version = 1, exportSchema = false)
public abstract class MsgDatabase extends RoomDatabase {
    public abstract TextMsgDao textMsgDao();
}
