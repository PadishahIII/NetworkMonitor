package bishe.networkmonitor;

import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ListView;

import java.util.List;

import bishe.networkmonitor.dao.MsgDatabase;
import bishe.networkmonitor.dao.MsgDatabaseSingleton;
import bishe.networkmonitor.dao.TextMsg;
import bishe.networkmonitor.dao.TextMsgDao;

public class MsgActivity extends AppCompatActivity {
    private  MsgDatabase msgDatabase;
    private TextMsgDao dao;
    private List<TextMsg> msgList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        this.msgDatabase = MsgDatabaseSingleton.getInstance(getApplicationContext(), getString(R.string.database_name), getString(R.string.database_asset_path))
                .getDatabase();
        this.dao = msgDatabase.textMsgDao();
        buildAllMsg();

//        MsgListAdapter msgListAdapter = new MsgListAdapter(getApplicationContext(),this.msgList);
//        ListView listView = (ListView) findViewById(R.id.msglist);
//        listView.setAdapter(msgListAdapter);

        setContentView(R.layout.activity_msg);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }
    public void buildAllMsg(){
        this.msgList = this.dao.getAll();
    }


}
