package bishe.networkmonitor.dao;

import android.content.Context;

import androidx.room.Room;
import bishe.networkmonitor.ConnReader;
import bishe.networkmonitor.R;

/**
 * Created by Dell on 5/1/2023.
 */

public class MsgDatabaseSingleton {
    private static MsgDatabaseSingleton mInstance;
    private MsgDatabase msgDatabase;

    private MsgDatabaseSingleton(Context context, String databaseName, String databaseAssetPath) {
        this.msgDatabase = Room.databaseBuilder(context, MsgDatabase.class, databaseName)
                .createFromAsset(databaseAssetPath)
                .build();
    }

    public static MsgDatabaseSingleton getInstance(Context context, String databaseName, String databaseAssetPath) {
        if (mInstance == null) {
            mInstance = new MsgDatabaseSingleton(context, databaseName, databaseAssetPath);
        }
        return mInstance;
    }
    public MsgDatabase getDatabase(){
        return this.msgDatabase;
    }

}
