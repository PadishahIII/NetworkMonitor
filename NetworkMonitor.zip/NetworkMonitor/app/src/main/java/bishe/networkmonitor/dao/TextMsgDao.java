package bishe.networkmonitor.dao;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

/**
 * Created by Dell on 5/1/2023.
 */

@Dao
public interface TextMsgDao {
    @Query("select * from textMsg")
    List<TextMsg> getAll();

    @Query("select count(*) from textMsg")
    int getCount();

    @Query("select * from textMsg where timestamp>:timestamp")
    List<TextMsg> getMsgAfter(Long timestamp);

    @Query("select max(id) from textMsg")
    int getMaxId();

    @Insert
    void insert(TextMsg textMsg);

    @Insert
    void insertAll(TextMsg... textMsgs);
}
