package bishe.networkmonitor.dao;

import java.io.Serializable;
import java.util.Date;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * Created by Dell on 5/1/2023.
 */
@Entity
public class TextMsg implements Serializable {
    @PrimaryKey
    public int id;

    @ColumnInfo(name = "uid")
    public int uid;
    @ColumnInfo(name = "type")
    public String type;
    @ColumnInfo(name = "remoteHost")
    public String remoteHost;
    @ColumnInfo(name = "remotePort")
    public int remotePort;
    @ColumnInfo(name = "localPort")
    public int localPort;
    @ColumnInfo(name = "primaryText")
    public String primaryText;
    @ColumnInfo(name = "from")
    public int from;
    @ColumnInfo(name = "to")
    public int to;
    @ColumnInfo(name = "timestamp")
    public Long timestamp;
    @ColumnInfo(name = "level")
    public int level;

    @Override
    public String toString() {
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append("uid=" + Integer.toString(this.uid) + "\n");
        stringBuffer.append("type=" + this.type + "\n");
        stringBuffer.append("remoteHost=" + this.remoteHost + "\n");
        stringBuffer.append("remoteHost=" + this.remoteHost + "\n");
        stringBuffer.append("remotePort=" + Integer.toString(this.remotePort) + "\n");
        stringBuffer.append("localPort=" + Integer.toString(this.localPort) + "\n");
        stringBuffer.append("level=" + Integer.toString(this.level) + "\n");
        stringBuffer.append("Text=" + this.primaryText + "\n");
        stringBuffer.append("targetText=" + this.primaryText.substring(this.from, this.to + 1) + "\n");
        stringBuffer.append("date=" + (new Date(this.timestamp)).toString() + "\n");
        return stringBuffer.toString();


    }
}
